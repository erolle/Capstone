<?php include("views/head.php"); ?>

<div class="row">
    <div class="col-md-8">
    <h1>Support</h1>
    <h2>Help page</h2>
    <p>If you are having trouble or have questions, comments or concerns, please contact me with the form to the right, or email me directly at <a href="mailto:eer6344@rit.edu">eer6344@rit.edu</a></p>
    </div>
    <div class="col-md-4">
        <div id="wufoo-zi5wdvt0pjevcm">
Fill out my <a href="https://causbuzz2.wufoo.com/forms/zi5wdvt0pjevcm">online form</a>.
</div>
<div id="wuf-adv" style="font-family:inherit;font-size: small;color:#a7a7a7;text-align:center;display:block;">Use <a href="http://www.wufoo.com/partners/">Wufoo integrations</a> and get your data to your favorite apps.</div>
<script type="text/javascript">var zi5wdvt0pjevcm;(function(d, t) {
var s = d.createElement(t), options = {
'userName':'causbuzz2',
'formHash':'zi5wdvt0pjevcm',
'autoResize':true,
'height':'437',
'async':true,
'host':'wufoo.com',
'header':'show',
'ssl':true};
s.src = ('https:' == d.location.protocol ? 'https://' : 'http://') + 'www.wufoo.com/scripts/embed/form.js';
s.onload = s.onreadystatechange = function() {
var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
try { zi5wdvt0pjevcm = new WufooForm();zi5wdvt0pjevcm.initialize(options);zi5wdvt0pjevcm.display(); } catch (e) {}};
var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
})(document, 'script');</script>
    </div>
</div>

<?php include("views/foot.php"); ?>
