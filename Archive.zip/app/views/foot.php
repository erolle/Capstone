 </div>
   <br><br><br>
    <nav class="navbar navbar-default navbar-fixed-bottom">
      <div class="container">
       <ul class="nav navbar-nav">
            <li><a>Barrier Mazes</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="consent_form.php">Informed Concent Form</a></li>
            <li></li>
        </ul>
      </div>
    </nav>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="Vendors/bootstrap/js/bootstrap.min.js"></script>
    <!-- Includ the ink blot generator -->
    <script type="text/javascript" src="Vendors/Inkblot/rorschach.js"></script>
    <script type="text/javascript" src="Vendors/Inkblot/ink_settings.js"></script>
    <script type="text/javascript" src="Vendors/sha512/sha512.js "></script>
  </body>
</html>
