<?php
include("views/head.php");
require_once("classes/Login.php");

?>

<div class='jumbotron alert alert-success'>
  <div class='container'>
    <h1 style="text-align: center;">Thank See you Next Week</h1>
    <p style="text-align: center;"><img src="img/IMG_2038.JPG" alt="Erroyl with tall man" ></p>
    </div>
</div>




<?php
include("views/foot.php");
?>