<?php
include("views/head.php");
require_once("classes/Login.php");

?>
<div class="jumbotron">
  <h1>Thank you for participating in the study! </h1>
  <p>We've gathered all of the data that we need.  We really appreciate your help with this study.</p>
</div>

<iframe src="https://docs.google.com/forms/d/17Njw40K829w_FZxHDoy16tuKFDwhHMPzqrRrtf9kBW8/viewform?embedded=true" width="760" height="1500" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>






<?php
include("views/foot.php");
?>




