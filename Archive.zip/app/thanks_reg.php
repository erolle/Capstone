<?php
include("views/head.php");
require_once("classes/Login.php");

?>
<div class="jumbotron">
  <h1>Thank you for registring</h1>
  <p>Please remember your password(s), but do not write them down. Lets try loging in for the first time</p>
  <p><a href="login.php" class="btn btn-primary btn-lg" href="#" role="button">Longin Now!</a></p>
</div>









<?php
include("views/foot.php");
?>
