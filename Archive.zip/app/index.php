<?php
include("views/head.php");
require_once("classes/Login.php");

?>
<div class="jumbotron">
  <h1>Welcome</h1>
  <p>This study focuses on the advancement of computer security systems, specifically to promote the use of passwords that are sufficiently strong, yet user-friendly.</p>
  <p><a href="consent_form.php" class="btn btn-primary btn-lg" href="#" role="button">Sign up now!</a></p>
</div>









<?php
include("views/foot.php");
?>
