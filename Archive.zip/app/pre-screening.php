<?php
include("views/head.php");
require_once("classes/Login.php");

?>


<div id="wufoo-szx482l1gecmsh">
Fill out my <a href="https://causbuzz2.wufoo.com/forms/szx482l1gecmsh">online form</a>.
</div>
<script type="text/javascript">var szx482l1gecmsh;(function(d, t) {
var s = d.createElement(t), options = {
'userName':'causbuzz2',
'formHash':'szx482l1gecmsh',
'autoResize':true,
'height':'1246',
'async':true,
'host':'wufoo.com',
'header':'show',
'ssl':true};
s.src = ('https:' == d.location.protocol ? 'https://' : 'http://') + 'www.wufoo.com/scripts/embed/form.js';
s.onload = s.onreadystatechange = function() {
var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
try { szx482l1gecmsh = new WufooForm();szx482l1gecmsh.initialize(options);szx482l1gecmsh.display(); } catch (e) {}};
var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
})(document, 'script');</script>



<?php
include("views/foot.php");
?>
